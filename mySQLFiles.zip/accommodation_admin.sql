-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: accommodation
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `AdminID` int NOT NULL,
  `FullName` varchar(200) DEFAULT NULL,
  `EmailAddress` char(200) DEFAULT NULL,
  `PhoneNumber` int DEFAULT NULL,
  `Password` char(100) NOT NULL,
  PRIMARY KEY (`AdminID`),
  UNIQUE KEY `AdminID` (`AdminID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'Ahmed Kamal','ahmedkamal@gmail.com',9543210,'ahmed123'),(2,'Sarah Omar','sarahomar@gmail.com',9543211,'sarah123'),(3,'Mohammed Ali','mohammedali@gmail.com',9873212,'mohammed123'),(4,'Nada Adel','nadaadel@gmail.com',9876213,'nada123'),(5,'Aisha Magdy','aishamagdy@gmail.com',9873214,'aisha123'),(6,'Osama Ahmed','osamaahmed@gmail.com',9843215,'osama123'),(7,'Rania Nabil','ranianabil@gmail.com',9843216,'rania123'),(8,'Mahmoud Tarek','mahmoudtarek@gmail.com',6543217,'mahmoud123'),(9,'Mariam Samir','mariamsamir@gmail.com',6543218,'mariam123'),(10,'Yasser Hossam','yasserhossam@gmail.com',6543219,'yasser123'),(11,'Reham Kareem','rehamkareem@gmail.com',9543221,'reham123'),(12,'Hassan Tamer','hassantamer@gmail.com',9876522,'hassan123'),(13,'Amira Fady','amirafady@gmail.com',6543223,'amira123'),(14,'Mona Nour','monanour@gmail.com',6543224,'mona123'),(15,'Ahmed Ayman','ahmedayman@gmail.com',9876543,'ahmed123'),(16,'Nourhan Adel','nourhanadel@gmail.com',6543226,'nourhan123'),(17,'Mohammed Tarek','mohammedtarek@gmail.com',6543227,'mohammed123'),(18,'Sarah Mohamed','sarahmohamed@gmail.com',6543228,'sarah123'),(19,'Ahmed Samir','ahmedsamir@gmail.com',6543229,'ahmed123'),(20,'Hoda Nabil','hodanabil@gmail.com',9873230,'hoda123');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-25 21:25:21
