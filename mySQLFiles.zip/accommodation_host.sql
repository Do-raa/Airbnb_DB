-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: accommodation
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `host`
--

DROP TABLE IF EXISTS `host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host` (
  `HostID` int NOT NULL,
  `FisrtName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `EmailAddress` varchar(100) DEFAULT NULL,
  `PhoneNumber` int DEFAULT NULL,
  `Password` char(100) NOT NULL,
  `Nationality` char(200) DEFAULT NULL,
  `Photo` varbinary(1500) DEFAULT NULL,
  PRIMARY KEY (`HostID`),
  UNIQUE KEY `HostID` (`HostID`),
  UNIQUE KEY `EmailAddress` (`EmailAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host`
--

LOCK TABLES `host` WRITE;
/*!40000 ALTER TABLE `host` DISABLE KEYS */;
INSERT INTO `host` VALUES (1,'John','Doe','john.doe@gmail.com',123456789,'password1','USA',_binary ''),(2,'Jane','Doe','jane.doe@gmail.com',987654321,'password2','UK',_binary ''),(3,'Jack','Smith','jack.smith@gmail.com',121212121,'password3','Canada',_binary ''),(4,'Jill','Smith','jill.smith@gmail.com',343434343,'password4','Australia',_binary ''),(5,'James','Johnson','james.johnson@gmail.com',565656565,'password5','France',_binary ''),(6,'Emily','Johnson','emily.johnson@gmail.com',787878787,'password6','Germany',_binary ''),(7,'Michael','Williams','michael.williams@gmail.com',919191919,'password7','Italy',_binary ''),(8,'Sarah','Williams','sarah.williams@gmail.com',101010101,'password8','Spain',_binary ''),(9,'William','Brown','william.brown@gmail.com',111111111,'password9','Russia',_binary '	'),(10,'Elizabeth','Brown','elizabeth.brown@gmail.com',121212121,'password10','Japan',_binary '\n'),(11,'David','Jones','david.jones@gmail.com',1313131313,'password11','China',_binary ''),(12,'Karen','Jones','karen.jones@gmail.com',1414141414,'password12','India',_binary ''),(13,'Richard','Miller','richard.miller@gmail.com',1515151515,'password13','Brazil',_binary '\r'),(14,'Jessica','Miller','jessica.miller@gmail.com',1616161616,'password14','Mexico',_binary ''),(15,'Thomas','Davis','thomas.davis@gmail.com',1717171717,'password15','South Africa',_binary ''),(16,'Catherine','Davis','catherine.davis@gmail.com',1818181818,'password16','Canada',_binary ''),(17,'Charles','Wilson','charles.wilson@gmail.com',1919191919,'password17','France',_binary ''),(18,'Sophia','Wilson','sophia.wilson@gmail.com',2020202020,'password18','Germany',_binary ''),(19,'Matthew','Anderson','matthew.anderson@gmail.com',1234567908,'pass19','UK',NULL),(20,'Owen','King','owenking@example.com',1234567909,'pass20','Australia',NULL);
/*!40000 ALTER TABLE `host` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-25 21:25:21
