-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: accommodation
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `TransactionID` int NOT NULL,
  `Method` char(20) DEFAULT NULL,
  `Status` char(20) DEFAULT NULL,
  `Amount` double DEFAULT NULL,
  `_From` varchar(100) DEFAULT NULL,
  `_To` varchar(100) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `PaymentID` int DEFAULT NULL,
  `IncomeID` int DEFAULT NULL,
  PRIMARY KEY (`TransactionID`),
  UNIQUE KEY `TransactionID` (`TransactionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (1,'Credit Card','Approved',1000,'ahmed abdullah','John Doe','2022-10-01',1,1),(2,'Paypal','Declined',200,'muhammad ahmed','Jane Doe','2022-10-05',2,2),(3,'Bank Transfer','Pending',800,'ali muhammad','John Smith','2022-10-06',3,3),(4,'Credit Card','Approved',700,'nour abdulrahman','Jane Smith','2022-10-07',4,4),(5,'Paypal','Approved',500,'saeed muhammad','John Doe','2022-10-08',5,5),(6,'Bank Transfer','Declined',400,'osama ali','Jane Doe','2022-10-09',6,6),(7,'Credit Card','Pending',300,'amir muhammad','John Smith','2022-10-10',7,7),(8,'Paypal','Approved',200,'abdullah osama','Jane Smith','2022-10-11',8,8),(9,'Bank Transfer','Approved',100,'ahmed abdulaziz','John Doe','2022-10-12',9,9),(10,'Credit Card','Declined',800,'ali abdulrahman','Jane Doe','2022-10-13',10,10),(11,'Paypal','Pending',700,'nour muhammad','John Smith','2022-10-14',11,11),(12,'Bank Transfer','Approved',600,'Dorra Kahla','Hotel XYZ','2022-10-15',12,12),(13,'Credit Card','Approved',500,'saeed ahmed','John Doe','2022-10-16',13,13),(14,'Paypal','Declined',400,'Jane Doe','Hotel XYZ','2022-10-17',14,14),(15,'Bank Transfer','Pending',300,'John Smith','osama abdullah','2022-10-18',15,15),(16,'Credit Card','Approved',200,'Rayen jen','Adams','2022-10-19',16,16),(17,'Paypal','Approved',100,'Elizabeth Doe','Nawres kahla','2022-10-20',17,17),(18,'Bank Transfer','Declined',800,'Chris Brown','Emir Qatar','2022-10-21',18,18),(19,'Credit Card','Pending',700,'Lilia lasmer','Abdessalem lahmer','2022-10-21',19,19),(20,'Credit Card','Pending',700,'Hayder kahla','Fedi azaiz','2022-10-21',20,20);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-25 21:25:20
