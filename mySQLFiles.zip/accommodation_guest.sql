-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: accommodation
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest` (
  `GuestID` int NOT NULL,
  `FisrtName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `EmailAddress` varchar(100) DEFAULT NULL,
  `PhoneNumber` int DEFAULT NULL,
  `Password` char(100) NOT NULL,
  `Nationality` char(200) DEFAULT NULL,
  `MaritalStatus` varchar(40) DEFAULT NULL,
  `Job` char(60) DEFAULT NULL,
  PRIMARY KEY (`GuestID`),
  UNIQUE KEY `GuestID` (`GuestID`),
  UNIQUE KEY `EmailAddress` (`EmailAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest`
--

LOCK TABLES `guest` WRITE;
/*!40000 ALTER TABLE `guest` DISABLE KEYS */;
INSERT INTO `guest` VALUES (1,'ahmed','abdullah','ahmed.abdullah@gmail.com',123456789,'password1','Egyptian','Married','Doctor'),(2,'muhammad','أahmed','muhammad.ahmed@gmail.com',987654321,'password2','Moroccan','Single','Engineer'),(3,'ali','muhammad','ali.muhammad@gmail.com',111111111,'password3','Tunisian','Married','Teacher'),(4,'nour','abdulrahman','nour.abdulrahman@gmail.com',222222222,'password4','Algerian','Single','Lawyer'),(5,'saeed','muhammad','saeed.muhammad@gmail.com',333333333,'password5','Sudanese','Married','Journalist'),(6,'أosama','ali','osama.ali@gmail.com',444444444,'password6','Libyan','Single','Architect'),(7,'Ava','Miller','avamiller1@email.com',1234567896,'password7','British','Single','Engineer'),(8,'Isabella','Davis','isabelladavis1@email.com',1234567897,'password8','Australian','Married','Nurse'),(9,'Mia','Wilson','miawilson1@email.com',1234567898,'password9','American','Single','Teacher'),(10,'Charlotte','Wood','charlottewood1@email.com',1234567899,'password10','Canadian','Married','Doctor'),(11,'Amelia','Hill','ameliahill1@email.com',1234567800,'password11','British','Single','Engineer'),(12,'Harper','Lewis','harperlewis1@email.com',1234567801,'password12','Australian','Married','Nurse'),(13,'Evelyn','Green','evelyngreen1@email.com',1234567802,'password13','American','Single','Teacher'),(14,'Abigail','Adams','abigailadams1@email.com',1234567803,'password14','Canadian','Married','Doctor'),(15,'Emily','Baker','emilybaker1@email.com',1234567804,'password15','British','Single','Engineer'),(16,'Elizabeth','Barnes','elizabethbarnes1@email.com',1234567805,'password16','Australian','Married','Nurse'),(17,'muhammad','lahmer','muhammad.lahmer@gmail.com',888888888,'password17','Ghanaian','Single','Painter'),(18,'ali','abdulrahman','ali.abdulrahman@gmail.com',999999999,'password18','Cameroonian','Married','Scientist'),(19,'nour','muhammad','nour.muhammad@gmail.com',101010101,'password19','Kenyan','Single','Programmer'),(20,'saeed','ahmed','saeed.ahmed@gmail.com',202020202,'password20','Zimbabwean','Married','Banker');
/*!40000 ALTER TABLE `guest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-25 21:25:20
