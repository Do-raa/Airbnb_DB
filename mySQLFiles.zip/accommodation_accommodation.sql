-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: accommodation
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accommodation`
--

DROP TABLE IF EXISTS `accommodation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accommodation` (
  `AccommodationID` int NOT NULL,
  `Description` text,
  `Price` double DEFAULT NULL,
  `HostID` int DEFAULT NULL,
  PRIMARY KEY (`AccommodationID`),
  UNIQUE KEY `AccommodationID` (`AccommodationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accommodation`
--

LOCK TABLES `accommodation` WRITE;
/*!40000 ALTER TABLE `accommodation` DISABLE KEYS */;
INSERT INTO `accommodation` VALUES (1,'Nice and cozy apartment located in the city center',1000,1),(2,'Beautiful villa with a private pool and large garden',1500,2),(3,'Spacious room in a shared house',500,3),(4,'Comfortable studio with a view of the city',800,4),(5,'Stylish apartment with a rooftop terrace',1200,5),(6,'Charming cottage with a fireplace',700,6),(7,'Modern apartment with a large kitchen',1100,7),(8,'Luxury apartment with a Jacuzzi',1700,8),(9,'Elegant apartment with a balcony',1300,9),(10,'Rustic cabin in the woods',600,10),(11,'Stylish penthouse with a rooftop pool',2000,11),(12,'Cozy room in a bed and breakfast',400,12),(13,'Vintage apartment in a historic building',900,13),(14,'Bright and airy apartment with a balcony',1000,14),(15,'Comfortable room in a shared apartment',450,15),(16,'Spacious apartment with a large living room',1200,16),(17,'Elegant apartment with a fireplace',1300,17),(18,'Luxury villa with a private pool',2000,18),(19,'Stylish apartment with a roof garden',1500,19),(20,'Comfortable apartment with a view of the park',900,20);
/*!40000 ALTER TABLE `accommodation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-25 21:25:21
